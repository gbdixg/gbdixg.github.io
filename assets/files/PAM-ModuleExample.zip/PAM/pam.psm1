
$PAMConfig = Get-PSSessionConfiguration -Name 'PAM'
If ($null -eq $PAMConfig) {
    # Need to register the PowerShell Endpoint

    # Register using the session configuration file
    Register-PSSessionConfiguration -Name 'PAM' -path "$PSScriptRoot\PAM.pssc" | out-null

    # Update the security descriptor to remove over-the-network access
    Set-PSSessionConfiguration -Name 'PAM' -SecurityDescriptorSddl 'O:NSG:BAD:P(D;;GA;;;NU)(A;;GA;;;DU)S:P(AU;FA;GA;;;WD)(AU;SA;GXGW;;;WD)' | out-null
}

# Define the custom functions that can run elevated

Function Update-Hosts {
    <#
        .SYNOPSIS
          Example - Updating the HOSTS file requires elevated access
    #>
    [cmdletBinding()]
    param(
        [string]$IP
        ,
        [string]$Hostname
    )
    PROCESS {
        $Text = ("{0}     {1}" -f $IP, $Hostname)
        try {
            $Text | Add-Content -Path 'C:\windows\System32\drivers\etc\hosts' -ErrorAction Stop
        } catch {
            throw "Failed to update hosts '$_'"
        }
    }
}


Function Get-GPEvent {
    <#
        .SYNOPSIS
          Example - Reading the GroupPolicy event log requires elevated access
    #>
    [cmdletBinding()]
    param()
    PROCESS {
        Get-WinEvent -LogName 'Microsoft-Windows-GroupPolicy/Operational'
    }
}
